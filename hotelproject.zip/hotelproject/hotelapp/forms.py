from django import forms 
from .models import Booking, Contact 
class BookingForm(forms.ModelForm): 
    class Meta: 
        model = Booking 
        fields = ['customer_name', 'email', 'phone', 'room', 'check_in', 'check_out'] 
        widgets = { 
            'check_in': forms.DateInput(attrs={'type': 'date'}), 
            'check_out': forms.DateInput(attrs={'type': 'date'}), 
        } 
class ContactForm(forms.ModelForm): 
    class Meta: 
        model = Contact 
        fields = ['name', 'email', 'phone', 'message'] 
